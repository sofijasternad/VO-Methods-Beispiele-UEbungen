package Arrays;

public class Primes {
}
