package Arrays;

public class SquaresArray {
    public static void main(String[] args) {
        int[] squares = {1,2, 4, 16, 32, 64, 128, 256};
        System.out.println("Länge von Array: " + squares.length);
        System.out.println(squares[0]);
        System.out.println(squares[4]);
    }
}
