package methods;

public class AnzahlZiffern {
}
