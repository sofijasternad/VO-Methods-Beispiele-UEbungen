package methods;

public class AnzahlZiffernGlobal {
}
