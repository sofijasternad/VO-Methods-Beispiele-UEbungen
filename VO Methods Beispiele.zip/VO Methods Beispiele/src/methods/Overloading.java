package methods;

public class Overloading {
}
