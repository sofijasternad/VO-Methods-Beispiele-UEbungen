package loops;

public class Fakultaet {
}
