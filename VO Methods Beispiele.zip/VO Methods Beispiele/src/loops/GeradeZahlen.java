package loops;

public class GeradeZahlen {
}
