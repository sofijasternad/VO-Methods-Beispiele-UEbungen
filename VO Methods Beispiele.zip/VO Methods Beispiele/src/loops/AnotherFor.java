package loops;

public class AnotherFor {
}
